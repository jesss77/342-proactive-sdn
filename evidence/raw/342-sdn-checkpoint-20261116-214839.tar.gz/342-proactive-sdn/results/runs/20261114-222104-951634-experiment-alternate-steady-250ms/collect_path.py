"""Native-rate raw collector with per-read timing and process/child CPU accounting."""
import argparse
import json
import math
import signal
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path
from experiment_config import route_spec


def root_qdisc(stdout):
    roots = [q for q in json.loads(stdout) if q.get('root')]
    if len(roots) != 1:
        raise ValueError('Expected one root qdisc')
    return roots[0]


def collect(output, route='primary', interval=0.25, duration=60):
    spec = route_spec(route)
    if not math.isfinite(interval) or not math.isfinite(duration) or min(interval, duration) <= 0:
        raise ValueError('Positive finite interval and duration required')
    if Path(output).exists() or Path(str(output) + '.stats.json').exists():
        raise FileExistsError('Refusing to overwrite collector data or statistics')
    try:
        import resource
        def cpu():
            own = resource.getrusage(resource.RUSAGE_SELF)
            child = resource.getrusage(resource.RUSAGE_CHILDREN)
            return dict(self_s=own.ru_utime + own.ru_stime,
                        children_s=child.ru_utime + child.ru_stime)
    except ImportError:
        def cpu():
            return {}
    stopped = False
    def stop(_signal, _frame):
        nonlocal stopped
        stopped = True
    original_handlers = {s: signal.signal(s, stop) for s in [signal.SIGTERM, signal.SIGINT]}
    interfaces = sorted(set([spec['upstream'], spec['egress'], spec['ingress'],
                             's1-eth3', 's1-eth4', 's4-eth3', 's4-eth4']))
    start = deadline = time.monotonic()
    before_cpu = cpu()
    sequence = skipped = 0
    try:
        with Path(output).open('x') as f:
            while not stopped and time.monotonic() - start < duration:
                time.sleep(max(0, deadline - time.monotonic()))
                if stopped or time.monotonic() - start >= duration:
                    break
                row = dict(sample=sequence, utc=datetime.now(timezone.utc).isoformat(),
                           route=route, capacity_bps=spec['capacity_bps'], egress=spec['egress'],
                           monotonic_start=time.monotonic(), scheduled=deadline,
                           requested_interval=interval, skipped_before_sample=skipped,
                           interfaces={})
                for name in interfaces:
                    folder = Path('/sys/class/net') / name / 'statistics'
                    before = time.monotonic()
                    record = {}
                    try:
                        record.update({key: int((folder / key).read_text()) for key in
                                       ['tx_bytes', 'rx_bytes', 'tx_packets', 'rx_packets']})
                    except (OSError, ValueError) as error:
                        record['error'] = str(error)
                    record.update(read_start=before, read_end=time.monotonic())
                    row['interfaces'][name] = record
                row['tc_start'] = time.monotonic()
                try:
                    result = subprocess.run(
                        ['tc', '-j', '-s', 'qdisc', 'show', 'dev', spec['egress']],
                        capture_output=True, text=True, timeout=2)
                    row.update(tc_exit=result.returncode, tc_stdout=result.stdout,
                               tc_stderr=result.stderr)
                    if result.returncode == 0:
                        try:
                            row['root_qdisc'] = root_qdisc(result.stdout)
                        except (ValueError, TypeError) as error:
                            row['tc_error'] = str(error)
                except subprocess.TimeoutExpired:
                    row['tc_error'] = 'query exceeded 2 seconds'
                row['tc_end'] = row['monotonic_end'] = time.monotonic()
                f.write(json.dumps(row) + '\n')
                f.flush()
                sequence += 1
                deadline += interval
                skipped = 0
                if deadline < time.monotonic():
                    skipped = int((time.monotonic() - deadline) / interval) + 1
                    deadline += skipped * interval
    finally:
        for s, handler in original_handlers.items():
            signal.signal(s, handler)
        elapsed = time.monotonic() - start
        after_cpu = cpu()
        usage = {key: after_cpu[key] - value for key, value in before_cpu.items()}
        Path(str(output) + '.stats.json').write_text(json.dumps(dict(
            route=route, interval_s=interval, samples=sequence, elapsed_s=elapsed,
            cpu_seconds=usage, cpu_percent_one_core={
                key: 100 * value / elapsed for key, value in usage.items()},
            stopped_by_signal=stopped), indent=2))
    print('Saved', sequence, 'samples to', output, flush=True)


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('output')
    p.add_argument('--route', choices=['primary', 'alternate'], default='primary')
    p.add_argument('--interval', type=float, default=0.25)
    p.add_argument('--duration', type=float, default=60)
    args = p.parse_args()
    collect(args.output, args.route, args.interval, args.duration)
