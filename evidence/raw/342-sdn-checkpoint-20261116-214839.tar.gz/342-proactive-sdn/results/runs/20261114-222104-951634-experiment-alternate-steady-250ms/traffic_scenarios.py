"""Deterministic pilot schedules; independent segments are not seamless ramps."""
import random


def schedule(name='steady', rate=3_000_000, duration=20, seed=1):
    if name == 'steady':
        rows = [(rate, duration)]
    elif name == 'ramp':
        rows = [(bps * 1_000_000, 4) for bps in [3, 6, 9, 12, 15, 12, 9, 6, 3]]
    elif name == 'bursty':
        rng = random.Random(seed)
        rows = [(3_000_000 if i % 2 == 0 else rng.choice([12, 15]) * 1_000_000,
                 rng.choice([2, 3, 4])) for i in range(12)]
    else:
        raise ValueError('Unknown traffic scenario')
    if any(not isinstance(bps, int) or bps <= 0 or seconds <= 0 for bps, seconds in rows):
        raise ValueError('Positive integer rates and durations required')
    return [dict(segment=i, requested_bps=bps, requested_seconds=seconds)
            for i, (bps, seconds) in enumerate(rows)]
